/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practice;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 * @author Lord Geese
 */
public class AdminController implements Initializable {

    /**
     * Initializes the controller class.
     */
    //TABLE
    @FXML private TableView<UserInformation> table;
    @FXML private TableColumn<UserInformation, String> usernameColumn;
    @FXML private TableColumn<UserInformation, Integer> itemColumn1;
    @FXML private TableColumn<UserInformation, Integer> itemColumn2;
    @FXML private TableColumn<UserInformation, Integer> itemColumn3;
    @FXML private TableColumn<UserInformation, Integer> itemColumn4;
    @FXML private TableColumn<UserInformation, Integer> itemColumn5;
    @FXML private TableColumn<UserInformation, Integer> itemColumn6;
    @FXML private TableColumn<UserInformation, Integer> itemColumn7;
    @FXML private TableColumn<UserInformation, Integer> itemColumn8;
    @FXML private TableColumn<UserInformation, Integer> itemColumn9;
    @FXML private TableColumn<UserInformation, Integer> itemColumn10;
    
    //FUNCTIONAL BUTTONS
    @FXML
    Button displayFood, displayDrink, displayDessert, displayUser, searchButton, removeOrder, exitButton;
    
    @FXML 
    TextField searchBox;
    
    @FXML
    Label currentScreen;
    
    private String tableCurrentlyViewed;
    
    @FXML
    public void showFoodValues(){
        tableCurrentlyViewed = "food";
        
        currentScreen.setText("Food Orders");
        //Setting the header texts
        itemColumn1.setText("Caldereta w/ Rice");
        itemColumn2.setText("Dinuguan w/ Rice");
        itemColumn3.setText("Kare-Kare w/ Rice");
        itemColumn4.setText("Bagnet w/ Rice");
        itemColumn5.setText("Sisig");
        itemColumn6.setText("Tosilog");
        itemColumn7.setText("Hotsilog");
        itemColumn8.setText("Bacsilog");
        itemColumn9.setText("Tapsilog");
        itemColumn10.setText("Porksilog");
        
        //Putting values in the table
        usernameColumn.setCellValueFactory(new PropertyValueFactory<UserInformation, String>("name"));
        itemColumn1.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item1"));
        itemColumn2.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item2"));
        itemColumn3.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item3"));
        itemColumn4.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item4"));
        itemColumn5.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item5"));
        itemColumn6.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item6"));
        itemColumn7.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item7"));
        itemColumn8.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item8"));
        itemColumn9.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item9"));
        itemColumn10.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item10"));
        table.setItems(getFood());
    }
    
    @FXML
    public void showDrinkValues(){
        tableCurrentlyViewed = "drink";
        
        currentScreen.setText("Drink Orders");
        
        //Setting the header texts
        itemColumn1.setText("Coke");
        itemColumn2.setText("Sprite");
        itemColumn3.setText("Royal");
        itemColumn4.setText("Pepsi");
        itemColumn5.setText("Mango Shake");
        itemColumn6.setText("Chocolate Shake");
        itemColumn7.setText("Strawberry Shake");
        itemColumn8.setText("Vanilla Shake");
        itemColumn9.setText("");
        itemColumn10.setText("");
        
        //Putting values in the table
        usernameColumn.setCellValueFactory(new PropertyValueFactory<UserInformation, String>("name"));
        itemColumn1.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item1"));
        itemColumn2.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item2"));
        itemColumn3.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item3"));
        itemColumn4.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item4"));
        itemColumn5.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item5"));
        itemColumn6.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item6"));
        itemColumn7.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item7"));
        itemColumn8.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item8"));
        
        //These are excluded since drinks only have 8 values
        itemColumn9.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>(""));
        itemColumn10.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>(""));
        
        
        table.setItems(getDrinks());
    }
    
    @FXML
    public void showDessertValues(){
        tableCurrentlyViewed = "dessert";
        
        currentScreen.setText("Dessert Orders");
        
        //Setting the header texts
        itemColumn1.setText("Carrot Cake");
        itemColumn2.setText("Blueberry Cheesecake");
        itemColumn3.setText("Strawberry Cheesecake");
        itemColumn4.setText("Chocolate Cake");
        itemColumn5.setText("");
        itemColumn6.setText("");
        itemColumn7.setText("");
        itemColumn8.setText("");
        itemColumn9.setText("");
        itemColumn10.setText("");
        
        //Putting values in the table
        usernameColumn.setCellValueFactory(new PropertyValueFactory<UserInformation, String>("name"));
        itemColumn1.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item1"));
        itemColumn2.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item2"));
        itemColumn3.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item3"));
        itemColumn4.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item4"));
        
        //Excluded items
        itemColumn5.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>(""));
        itemColumn6.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>(""));
        itemColumn7.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>(""));
        itemColumn8.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>(""));
        itemColumn9.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>(""));
        itemColumn10.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>(""));
        
        table.setItems(getDesserts());
    }
    
    @FXML
    public void showUserValues(){
        tableCurrentlyViewed = "user";
        
        currentScreen.setText("User Summary");
        
        //Setting the header texts
        itemColumn1.setText("Total Amount to be Paid (in PHP)");
        itemColumn2.setText("");
        itemColumn3.setText("");
        itemColumn4.setText("");
        itemColumn5.setText("");
        itemColumn6.setText("");
        itemColumn7.setText("");
        itemColumn8.setText("");
        itemColumn9.setText("");
        itemColumn10.setText("");
        
        //Putting values in the table
        usernameColumn.setCellValueFactory(new PropertyValueFactory<UserInformation, String>("name"));
        itemColumn1.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item1"));
        
        //Excluded items
        itemColumn2.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>(""));
        itemColumn3.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>(""));
        itemColumn4.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>(""));
        itemColumn5.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>(""));
        itemColumn6.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>(""));
        itemColumn7.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>(""));
        itemColumn8.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>(""));
        itemColumn9.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>(""));
        itemColumn10.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>(""));
        
        table.setItems(getUsers());
    }
    
    @FXML
    public void showSearchedValues(){
        switch(tableCurrentlyViewed){
            case "food":
                usernameColumn.setCellValueFactory(new PropertyValueFactory<UserInformation, String>("name"));
                itemColumn1.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item1"));
                itemColumn2.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item2"));
                itemColumn3.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item3"));
                itemColumn4.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item4"));
                itemColumn5.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item5"));
                itemColumn6.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item6"));
                itemColumn7.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item7"));
                itemColumn8.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item8"));
                itemColumn9.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item9"));
                itemColumn10.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item10"));
                break;
            case "drink":
                usernameColumn.setCellValueFactory(new PropertyValueFactory<UserInformation, String>("name"));
                itemColumn1.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item1"));
                itemColumn2.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item2"));
                itemColumn3.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item3"));
                itemColumn4.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item4"));
                itemColumn5.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item5"));
                itemColumn6.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item6"));
                itemColumn7.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item7"));
                itemColumn8.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item8"));
                
                itemColumn9.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>(""));
                itemColumn10.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>(""));
                break;
            case "dessert":
                usernameColumn.setCellValueFactory(new PropertyValueFactory<UserInformation, String>("name"));
                itemColumn1.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item1"));
                itemColumn2.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item2"));
                itemColumn3.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item3"));
                itemColumn4.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item4"));
                
                itemColumn5.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>(""));
                itemColumn6.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>(""));
                itemColumn7.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>(""));
                itemColumn8.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>(""));
                itemColumn9.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>(""));
                itemColumn10.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>(""));
                break;
            case "user":
                //Putting values in the table
                usernameColumn.setCellValueFactory(new PropertyValueFactory<UserInformation, String>("name"));
                itemColumn1.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>("item1"));
                
                itemColumn2.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>(""));           
                itemColumn3.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>(""));
                itemColumn4.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>(""));
                itemColumn5.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>(""));
                itemColumn6.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>(""));
                itemColumn7.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>(""));
                itemColumn8.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>(""));
                itemColumn9.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>(""));
                itemColumn10.setCellValueFactory(new PropertyValueFactory<UserInformation, Integer>(""));
                break;
        }
        
        table.setItems(searchUser());
    }//Method End
    
    @FXML
    public void removeUserOrder(ActionEvent event) throws Exception{
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("OrderRemoval.fxml"));
        Parent root = loader.load();
        
        Stage window = new Stage();
        Scene removalScene = new Scene(root);
        window.setScene(removalScene);
        window.setTitle("Remove Order");
        window.setMaxWidth(630);
        window.setMaxHeight(410);
        window.show();
    }
    
    //Observable lists to be used in setting values in tables
    
    public ObservableList<UserInformation> getFood(){
        ObservableList<UserInformation> food;
        UserInformation g1 = new UserInformation();
        
        food = g1.accessDatabase("food");
        
        return food;
    }
    
    public ObservableList<UserInformation> getDrinks(){
        ObservableList<UserInformation> drink;
        UserInformation g1 = new UserInformation();

        drink = g1.accessDatabase("drink");
        
        return drink;
    }
    
    public ObservableList<UserInformation> getDesserts(){
        ObservableList<UserInformation> dessert;
        UserInformation g1 = new UserInformation();

        dessert = g1.accessDatabase("dessert");
        
        return dessert;
    }
    
    public ObservableList<UserInformation> getUsers(){
        ObservableList<UserInformation> user;
        UserInformation g1 = new UserInformation();

        user = g1.accessDatabase("user");
        
        return user;
    }
    
    public ObservableList<UserInformation> searchUser(){
        ObservableList<UserInformation> hanap;
        UserInformation lookup = new UserInformation();
        
        hanap = lookup.searchUser(searchBox.getText(), tableCurrentlyViewed);
        return hanap;
    }
    
    @FXML
    public void returnToLogin(ActionEvent event) throws Exception{
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("FXMLDocument.fxml"));
        Parent root = loader.load();
        
        Scene loginScene = new Scene(root);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.close();
        
        Stage next = new Stage();
        next.setScene(loginScene);
        next.setTitle("Login");
        next.centerOnScreen();
        next.show();
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        showFoodValues();
    }    
    
}
