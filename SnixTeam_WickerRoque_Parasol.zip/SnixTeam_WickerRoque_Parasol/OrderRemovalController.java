/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practice;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Lord Geese
 */
public class OrderRemovalController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML Button finishButton;
    @FXML TextField usernameBox;
    
    @FXML
    public void finishDeletion(ActionEvent event) throws Exception{
        if(!usernameBox.getText().isEmpty()){
            UserInformation dbMaster = new UserInformation();
            dbMaster.removePlacedOrder(usernameBox.getText());
            
            Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
            window.close();
        }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
