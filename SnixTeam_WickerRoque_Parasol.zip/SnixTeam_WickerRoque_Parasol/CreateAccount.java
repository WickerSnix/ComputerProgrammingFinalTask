/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practice;

import java.sql.*;

/**
 *
 * @author Lord Geese
 */
public class CreateAccount {
    //DATABASE ACCESS
    private String query;
    private String username = "seanWicker";
    private String password = "wicker";
    private String url = "jdbc:mysql://localhost:3306/foodOrders";
    private Connection conn;
    
    public void createNewUser(String newUserName){
        try{
            conn = DriverManager.getConnection(url, username, password);
            System.out.println("Accessing database!");
            
            query = "INSERT INTO foodAppUsers (username, has_order) VALUES (?,?)";
            PreparedStatement prep = conn.prepareStatement(query);
            prep.setString(1, newUserName);
            prep.setInt(2, 0);
            prep.execute();
            
            System.out.println("Successfully made a new user!");
            
        }catch(Exception e){
            System.out.println(e);
        }finally{
            try{
                conn.close();
            }catch(Exception e1){
                System.out.println(e1);
            }
        }
    }
}
