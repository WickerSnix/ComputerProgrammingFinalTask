/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practice;

import java.sql.*;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Lord Geese
 */
public class UserInformation {
    //Values to be displayed in the table
    private SimpleStringProperty name;
    private SimpleIntegerProperty item1, item2, item3, item4, item5, item6, item7, item8, item9, item10;
    
    //DATABASE ACCESS
    private String query;
    private String username = "seanWicker";
    private String password = "wicker";
    private String url = "jdbc:mysql://localhost:3306/foodOrders";
    private Connection conn;
    
    ObservableList<UserInformation> list, lookupList;
    private int user_id;
    
    //Constructor
    public UserInformation(){
        
    }
    
    public UserInformation(String name, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10){
        this.name = new SimpleStringProperty(name);
        this.item1 = new SimpleIntegerProperty(i1);
        this.item2 = new SimpleIntegerProperty(i2);
        this.item3 = new SimpleIntegerProperty(i3);
        this.item4 = new SimpleIntegerProperty(i4);
        this.item5 = new SimpleIntegerProperty(i5);
        this.item6 = new SimpleIntegerProperty(i6);
        this.item7 = new SimpleIntegerProperty(i7);
        this.item8 = new SimpleIntegerProperty(i8);
        this.item9 = new SimpleIntegerProperty(i9);
        this.item10 = new SimpleIntegerProperty(i10);
    }
    
    public ObservableList<UserInformation> accessDatabase(String category){
        try{
            conn = DriverManager.getConnection(url, username, password);
            System.out.println("Accessing database...");
            
            list = FXCollections.observableArrayList();
            if(category.equals("user")){
                query = "SELECT * FROM foodAppUsers";
            }
            else{
                query = "SELECT * FROM " +category+ "MenuOrders";
            }
            
            PreparedStatement prep = conn.prepareStatement(query);
            
            ResultSet rs = prep.executeQuery();
            while(rs.next()){
                String dbName = "";
                query = "SELECT username FROM foodAppUsers WHERE user_id = ?";
                
                prep = conn.prepareStatement(query);
                prep.setInt(1, rs.getInt("user_id"));
                
                ResultSet rss = prep.executeQuery();
                while(rss.next()){
                    dbName = rss.getString(1);
                }//While End
                
                //Continuously add data into the observable list
                switch(category){
                    case "food":
                        list.add(new UserInformation(dbName, rs.getInt("food1"), rs.getInt("food2"), rs.getInt("food3"),
                        rs.getInt("food4"), rs.getInt("food5"), rs.getInt("food6"), rs.getInt("food7"), rs.getInt("food8"),
                        rs.getInt("food9"), rs.getInt("food10")));
                        
                        break;
                    case "drink":
                        list.add(new UserInformation(dbName, rs.getInt("drink1"), rs.getInt("drink2"), rs.getInt("drink3"),
                        rs.getInt("drink4"), rs.getInt("drink5"), rs.getInt("drink6"), rs.getInt("drink7"), rs.getInt("drink8"),
                        0, 0));
                        
                        break;
                    case "dessert":
                        list.add(new UserInformation(dbName, rs.getInt("dessert1"), rs.getInt("dessert2"), 
                                rs.getInt("dessert3"), rs.getInt("dessert4"), 0, 0, 0, 0, 0, 0));
                        
                        break;
                    case "user":
                        list.add(new UserInformation(dbName, rs.getInt("has_order"), 0, 0, 0, 0, 0, 0, 0, 0, 0));
                        
                        break;
                }//Switch End        
            }//While End
            
            System.out.println("Values stored!");
            
        }catch(Exception e){
            System.out.println(e);
        }finally{
            try{
                conn.close();
            }catch(Exception e1){
                System.out.println(e1);
            }
        }//Finally End      
        return list;
    }//Method end
    
    public ObservableList<UserInformation> searchUser(String searchedUser, String currentTable){
        try{
            conn = DriverManager.getConnection(url, username, password);
            lookupList = FXCollections.observableArrayList();
            
            //GET THE USER ID FIRST
            query = "SELECT user_id FROM foodAppUsers WHERE username = ?";
            PreparedStatement prep = conn.prepareStatement(query);
            prep.setString(1, searchedUser);
            
            ResultSet rs = prep.executeQuery();
            while(rs.next()){
                user_id = rs.getInt(1);
            }
            System.out.println("User ID acquired: " + user_id);
            
            //GET THE DATA OF THE USER SEARCHED
            if(currentTable.equals("user")){
                query = "SELECT * FROM foodAppUsers WHERE user_id = ?";
            }
            else{
                query = "SELECT * FROM " + currentTable + "MenuOrders WHERE user_id = ?";
            }
            
            prep = conn.prepareStatement(query);
            prep.setInt(1, user_id);
            
            rs = prep.executeQuery();
            while(rs.next()){
                switch(currentTable){
                    case "food":
                        lookupList.add(new UserInformation(searchedUser, rs.getInt("food1"), rs.getInt("food2"), rs.getInt("food3"),
                        rs.getInt("food4"), rs.getInt("food5"), rs.getInt("food6"), rs.getInt("food7"), rs.getInt("food8"),
                        rs.getInt("food9"), rs.getInt("food10")));
                        break;
                    case "drink":
                        lookupList.add(new UserInformation(searchedUser, rs.getInt("drink1"), rs.getInt("drink2"), rs.getInt("drink3"),
                        rs.getInt("drink4"), rs.getInt("drink5"), rs.getInt("drink6"), rs.getInt("drink7"), rs.getInt("drink8"),
                        0, 0));
                        break;
                    case "dessert":
                        lookupList.add(new UserInformation(searchedUser, rs.getInt("dessert1"), 
                                rs.getInt("dessert2"), rs.getInt("dessert3"), rs.getInt("dessert4"), 0, 0, 0, 0, 0, 0));
                        break;
                    case "user":
                        lookupList.add(new UserInformation(searchedUser, rs.getInt("has_order"), 0, 0, 0, 0, 0, 0, 0, 0, 0));
                        break;
                }//Switch End             
            }//While End         
            System.out.println("ObservableList successfully made!");
            
        }catch(Exception e){
            System.out.println(e);
        }finally{
            try{
                conn.close();
            }catch(Exception e1){
                System.out.println(e1);
            }
        }
        return lookupList;
    }
    
    public void removePlacedOrder(String removed){
        try{
            conn = DriverManager.getConnection(url, username, password);
            System.out.println("Accessing database!");
            
            query = "SELECT user_id FROM foodAppUsers WHERE username = ?";
            PreparedStatement prep = conn.prepareStatement(query);
            prep.setString(1, removed);
            ResultSet rs = prep.executeQuery();
            
            int acquiredID = 0;
            
            while(rs.next()){
                acquiredID = rs.getInt("user_id");
            }
            System.out.println(acquiredID);
            
            query = "DELETE FROM foodMenuOrders WHERE user_id = ?";
            prep = conn.prepareStatement(query);
            prep.setInt(1, acquiredID);
            prep.execute();
            
            query = "DELETE FROM drinkMenuOrders WHERE user_id = ?";
            prep = conn.prepareStatement(query);
            prep.setInt(1, acquiredID);
            prep.execute();
            
            query = "DELETE FROM dessertMenuOrders WHERE user_id = ?";
            prep = conn.prepareStatement(query);
            prep.setInt(1, acquiredID);
            prep.execute();
            
            System.out.println("Successfully deleted all orders!");
            
            query = "UPDATE foodAppUsers SET has_order = ? WHERE username = ?";
            prep = conn.prepareStatement(query);
            prep.setInt(1, 0);
            prep.setString(2, removed);
            prep.execute();
            
            System.out.println("Removed unpaid order!");
        }catch(Exception e){
            System.out.println(e);
        }finally{
            try{
                conn.close();
            }catch(Exception e1){
                System.out.println(e1);
            }
        }
    }//Method End
    
    //GETTER AND SETTER VALUES
    public String getName() {
        return name.get();
    }

    public void setName(SimpleStringProperty name) {
        this.name = name;
    }

    public int getItem1() {
        return item1.get();
    }

    public void setItem1(SimpleIntegerProperty item1) {
        this.item1 = item1;
    }

    public int getItem2() {
        return item2.get();
    }

    public void setItem2(SimpleIntegerProperty item2) {
        this.item2 = item2;
    }

    public int getItem3() {
        return item3.get();
    }

    public void setItem3(SimpleIntegerProperty item3) {
        this.item3 = item3;
    }

    public int getItem4() {
        return item4.get();
    }

    public void setItem4(SimpleIntegerProperty item4) {
        this.item4 = item4;
    }

    public int getItem5() {
        return item5.get();
    }

    public void setItem5(SimpleIntegerProperty item5) {
        this.item5 = item5;
    }

    public int getItem6() {
        return item6.get();
    }

    public void setItem6(SimpleIntegerProperty item6) {
        this.item6 = item6;
    }

    public int getItem7() {
        return item7.get();
    }

    public void setItem7(SimpleIntegerProperty item7) {
        this.item7 = item7;
    }

    public int getItem8() {
        return item8.get();
    }

    public void setItem8(SimpleIntegerProperty item8) {
        this.item8 = item8;
    }

    public int getItem9() {
        return item9.get();
    }

    public void setItem9(SimpleIntegerProperty item9) {
        this.item9 = item9;
    }

    public int getItem10() {
        return item10.get();
    }

    public void setItem10(SimpleIntegerProperty item10) {
        this.item10 = item10;
    }
    
    
}
