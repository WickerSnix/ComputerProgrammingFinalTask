/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practice;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

/**
 *
 * @author Lord Geese
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    TextField username;
    @FXML
    Button confirmButton, createAccount;
    @FXML
    PasswordField password;
    
    @FXML
    public void ProceedtoMain(ActionEvent event) throws Exception{
        if(username.getText().equals("Admin") && password.getText().equals("lordgeese")){
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("Admin.fxml"));
            Parent root = loader.load();
            
            
            Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
            window.close();
            
            Stage next = new Stage();
            
            Scene adminScene = new Scene(root);
            next.setScene(adminScene);
            next.setTitle("Administrator");
            next.centerOnScreen();
            next.show();
        }
        else if(!username.getText().isEmpty() && !password.getText().isEmpty()){
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("Menu.fxml"));
            Parent root = loader.load();

            MenuController control = loader.getController();
            control.setUsername(username.getText());
            control.ChangeItemValues("Food", username.getText());
            control.currentScene = "Food";

            Scene loginScene = new Scene(root);
            Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
            window.close();

            Stage next = new Stage();

            next.setScene(loginScene);
            next.setTitle("Order");
            next.setMaxWidth(1235);
            next.setMaxHeight(848);
            next.centerOnScreen();
            next.show();
        } 
    }
    
    @FXML
    public void goToAccountCreation(ActionEvent event) throws Exception{
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("AccountCreationScreen.fxml"));
        Parent root = loader.load();
        
        Stage window = new Stage();
        Scene creationScene = new Scene(root);
        window.setScene(creationScene);
        window.setTitle("Create an Account");
        window.show();
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
