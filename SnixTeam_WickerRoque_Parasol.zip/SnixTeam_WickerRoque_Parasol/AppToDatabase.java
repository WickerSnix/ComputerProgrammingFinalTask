/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practice;

import java.sql.*;

/**
 *
 * @author Lord Geese
 */
public class AppToDatabase {
    private String query;
    private int userNumber;
    private String username = "seanWicker";
    private String password = "wicker";
    private String url = "jdbc:mysql://localhost:3306/foodOrders";
    private Connection conn;
    private int[] foodValues, drinkValues, dessertValues;
    
    public void StoreOrder(String user, int[][] FoodMenu, int[][] DrinkMenu, int[][] DessertMenu, int totalPrice){
        try{
            conn = DriverManager.getConnection(url, username, password);
            System.out.println("Lets go");
            
            //First get the id of the user
            query = "SELECT user_id FROM foodAppUsers WHERE username = ?";
            PreparedStatement prep = conn.prepareStatement(query);
            prep.setString(1, user);
            
            ResultSet rs = prep.executeQuery();
            while(rs.next()){
                userNumber = rs.getInt(1);
            }
            //Inserting values into the food menu orders DB
            query = "INSERT INTO foodMenuOrders (user_id, food1, food2, food3, food4, food5, food6, food7, food8,"
                    + " food9, food10) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
            
            prep = conn.prepareStatement(query);
            prep.setInt(1, userNumber);
            prep.setInt(2, FoodMenu[1][0]);
            prep.setInt(3, FoodMenu[1][1]);
            prep.setInt(4, FoodMenu[1][2]);
            prep.setInt(5, FoodMenu[1][3]);
            prep.setInt(6, FoodMenu[1][4]);
            prep.setInt(7, FoodMenu[1][5]);
            prep.setInt(8, FoodMenu[1][6]);
            prep.setInt(9, FoodMenu[1][7]);
            prep.setInt(10, FoodMenu[1][8]);
            prep.setInt(11, FoodMenu[1][9]);
            prep.execute();
            
            System.out.println("Food items successfully stored!");
            
            //Inserting values into the drink menu orders DB
            query = "INSERT INTO drinkMenuOrders (user_id, drink1, drink2, drink3, drink4, drink5, drink6, drink7, drink8)"
                    + "VALUES (?,?,?,?,?,?,?,?,?)";
            
            prep = conn.prepareStatement(query);
            prep.setInt(1, userNumber);
            prep.setInt(2, DrinkMenu[1][0]);
            prep.setInt(3, DrinkMenu[1][1]);
            prep.setInt(4, DrinkMenu[1][2]);
            prep.setInt(5, DrinkMenu[1][3]);
            prep.setInt(6, DrinkMenu[1][4]);
            prep.setInt(7, DrinkMenu[1][5]);
            prep.setInt(8, DrinkMenu[1][6]);
            prep.setInt(9, DrinkMenu[1][7]);
            prep.execute();
            
            System.out.println("Drink Items successfully stored");
            
            //Inserting values into the dessert menu orders DB
            query = "INSERT INTO dessertMenuOrders (user_id, dessert1, dessert2, dessert3, dessert4) "
                    + "VALUES (?,?,?,?,?)";
            
            prep = conn.prepareStatement(query);
            prep.setInt(1, userNumber);
            prep.setInt(2, DessertMenu[1][0]);
            prep.setInt(3, DessertMenu[1][1]);
            prep.setInt(4, DessertMenu[1][2]);
            prep.setInt(5, DessertMenu[1][3]);
            prep.execute();
            
            System.out.println("Dessert items successfully stored!");
            
            //Updating user values
            query = "UPDATE foodAppUsers SET has_order = ? WHERE user_id = ?";
            
            prep = conn.prepareStatement(query);
            prep.setInt(1, totalPrice);
            prep.setInt(2, userNumber);
            prep.execute();
            
            System.out.println("User successfully updated!");                    
        }
        catch(Exception e){
            System.out.println(e);
        }//Catch End
        finally{
            try{
                conn.close();
            }
            catch(Exception e1){
                System.out.println(e1);
            }
        }//Finally end
    }//Method end
    
}
