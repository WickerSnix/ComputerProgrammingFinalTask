/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practice;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

/**
 * FXML Controller class
 *
 * @author Lord Geese
 */
public class MenuController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    public int totalNumber, totalPrice;
    
    private int[][] FoodMenu = new int[2][10];
    private int[][] DrinkMenu = new int[2][8];
    private int[][] DessertMenu = new int[2][4];
    
    @FXML
    public String currentScene, userName;
    
    //RIGHT PANEL BUTTONS
    @FXML
    Button food, drinks, desserts, finishOrder, signOutButton;
    
    //LEFT PANEL BUTTONS
    //Increase the number of items
    @FXML
    Button order1, order2, order3, order4, order5, order6, order7, order8, order9, order10;
    
    //Decreases the number of items
    @FXML
    Button decrement1, decrement2, decrement3, decrement4, decrement5, decrement6,
            decrement7, decrement8, decrement9, decrement10;
    
    //LEFT PANEL LABELS
    //Item names
    @FXML
    Label priceLabel1, priceLabel2, priceLabel3, priceLabel4, priceLabel5, priceLabel6, priceLabel7,
            priceLabel8, priceLabel9, priceLabel10;
    @FXML
    Label ItemName1, ItemName2, ItemName3, ItemName4, ItemName5, ItemName6, ItemName7, ItemName8,
            ItemName9, ItemName10;
    //Item quantity
    @FXML
    Label itemQuantity1, itemQuantity2, itemQuantity3, itemQuantity4, itemQuantity5, itemQuantity6,
            itemQuantity7, itemQuantity8, itemQuantity9, itemQuantity10;
    
    @FXML
    Label numberOfItems, grandTotal;
    
    @FXML
    public void setCurrentScreen(String screen){
        this.currentScene = screen;
    }
    
    @FXML
    public void setUsername(String name){
        this.userName = name;
    }
    
    @FXML
    public void setTotalNumber(int number, int totalPrice){
        this.totalNumber = number;
        this.totalPrice = totalPrice;
        this.numberOfItems.setText("" + number);
        this.grandTotal.setText("PHP\t" + totalPrice + ".00");
    }
    //Transfer the values of the array to the next scene
    @FXML
    public void transferValues(int[][] FoodMenu, int[][] DrinkMenu, int[][] DessertMenu){
        this.FoodMenu = FoodMenu;
        this.DrinkMenu = DrinkMenu;
        this.DessertMenu = DessertMenu;
        
        switch(currentScene){
            case "Food":
                itemQuantity1.setText("" + this.FoodMenu[1][0]);
                itemQuantity2.setText("" + this.FoodMenu[1][1]);
                itemQuantity3.setText("" + this.FoodMenu[1][2]);
                itemQuantity4.setText("" + this.FoodMenu[1][3]);
                itemQuantity5.setText("" + this.FoodMenu[1][4]);
                itemQuantity6.setText("" + this.FoodMenu[1][5]);
                itemQuantity7.setText("" + this.FoodMenu[1][6]);
                itemQuantity8.setText("" + this.FoodMenu[1][7]);
                itemQuantity9.setText("" + this.FoodMenu[1][8]);
                itemQuantity10.setText("" + this.FoodMenu[1][9]);
                break;
            case "Drinks":
                itemQuantity1.setText("" + this.DrinkMenu[1][0]);
                itemQuantity2.setText("" + this.DrinkMenu[1][1]);
                itemQuantity3.setText("" + this.DrinkMenu[1][2]);
                itemQuantity4.setText("" + this.DrinkMenu[1][3]);
                itemQuantity5.setText("" + this.DrinkMenu[1][4]);
                itemQuantity6.setText("" + this.DrinkMenu[1][5]);
                itemQuantity7.setText("" + this.DrinkMenu[1][6]);
                itemQuantity8.setText("" + this.DrinkMenu[1][7]);
                break;
            case "Desserts":
                itemQuantity1.setText("" + this.DessertMenu[1][0]);
                itemQuantity2.setText("" + this.DessertMenu[1][1]);
                itemQuantity3.setText("" + this.DessertMenu[1][2]);
                itemQuantity4.setText("" + this.DessertMenu[1][3]);
                break;
        }
    }
    
    //Reloads the window with the labels set as "food"
    @FXML
    public void CategoryPressed(ActionEvent event) throws Exception{
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("Menu.fxml"));
        Parent category = loader.load();
        
        MenuController control = loader.getController();
        //If the "food" button is pressed, set the labels as food
        if((Button)event.getSource() == food){
            control.ChangeItemValues(food.getText(), userName);
            control.setCurrentScreen("Food");
            control.setTotalNumber(totalNumber, totalPrice);
            control.transferValues(FoodMenu, DrinkMenu, DessertMenu);
        }
        else if((Button)event.getSource() == drinks){
            control.ChangeItemValues(drinks.getText(), userName);
            control.setCurrentScreen("Drinks");
            control.setTotalNumber(totalNumber, totalPrice);
            control.transferValues(FoodMenu, DrinkMenu, DessertMenu);
        }
        else if((Button)event.getSource() == desserts){
            control.ChangeItemValues(desserts.getText(), userName);
            control.setCurrentScreen("Desserts");
            control.setTotalNumber(totalNumber, totalPrice);
            control.transferValues(FoodMenu, DrinkMenu, DessertMenu);
        }
        
        Scene loginScene = new Scene(category);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(loginScene);
        window.show();
    }
    
    //Method for looping through item names
    @FXML
    public void ChangeItemValues(String buttonTitle, String user){
        this.userName = user;
        String item;
        for(int i = 1; i < 11; i++){
           item = "ItemName" + i;
           
           //Change the values if the Food button is pressed
           if(buttonTitle.equals("Food")){
               //Set Food Titles
               switch(item){
                    case "ItemName1":
                        ItemName1.setText("Caldereta with Rice");
                        priceLabel1.setText("PHP 80.00");
                        break;
                    case "ItemName2":
                        ItemName2.setText("Dinuguan with Rice");
                        priceLabel2.setText("PHP 60.00");
                        break;
                    case "ItemName3":
                        ItemName3.setText("Kare-Kare with Rice");
                        priceLabel3.setText("PHP 90.00");
                        break;
                    case "ItemName4":
                        ItemName4.setText("Bagnet with Rice");
                        priceLabel4.setText("PHP 100.00");
                        break;
                    case "ItemName5":
                        ItemName5.setText("Sisig");
                        priceLabel5.setText("PHP 60.00");
                        break;
                    case "ItemName6":
                        ItemName6.setText("Tocilog");
                        priceLabel6.setText("PHP 60.00");
                        break;
                    case "ItemName7":
                        ItemName7.setText("Hotsilog");
                        priceLabel7.setText("PHP 45.00");
                        break;
                    case "ItemName8":
                        ItemName8.setText("Bacsilog");
                        priceLabel8.setText("PHP 60.00");
                        break;
                    case "ItemName9":
                        ItemName9.setText("Tapsilog");
                        priceLabel9.setText("PHP 60.00");
                        break;
                    case "ItemName10":
                        ItemName10.setText("Porksilog");
                        priceLabel10.setText("PHP 50.00");
                        break;
               }//Switch End
           }//If end
           else if(buttonTitle.equals("Drinks")){
                switch(item){
                    case "ItemName1":
                        ItemName1.setText("Coke");
                        priceLabel1.setText("PHP 15.00");
                        break;
                    case "ItemName2":
                        ItemName2.setText("Sprite");
                        priceLabel2.setText("PHP 15.00");
                        break;
                    case "ItemName3":
                        ItemName3.setText("Royal");
                        priceLabel3.setText("PHP 15.00");
                        break;
                    case "ItemName4":
                        ItemName4.setText("Pepsi");
                        priceLabel4.setText("PHP 15.00");
                        break;
                    case "ItemName5":
                        ItemName5.setText("Mango Shake");
                        priceLabel5.setText("PHP 45.00");
                        break;
                    case "ItemName6":
                        ItemName6.setText("Chocolate Shake");
                        priceLabel6.setText("PHP 45.00");
                        break;
                    case "ItemName7":
                        ItemName7.setText("Strawberry Shake");
                        priceLabel7.setText("PHP 45.00");
                        break;
                    case "ItemName8":
                        ItemName8.setText("Vanilla Shake");
                        priceLabel8.setText("PHP 45.00");
                        break;
                    case "ItemName9":
                        ItemName9.setText("");
                        priceLabel9.setText("");
                        itemQuantity9.setText("");
                        order9.setVisible(false);
                        decrement9.setVisible(false);
                        break;
                    case "ItemName10":
                        ItemName10.setText("");
                        priceLabel10.setText("");
                        itemQuantity10.setText("");
                        order10.setVisible(false);
                        decrement10.setVisible(false);
                        break;
               }//Switch end
           }//Else if end
           else if(buttonTitle.equals("Desserts")){
                switch(item){
                    case "ItemName1":
                        ItemName1.setText("Carrot Cake");
                        priceLabel1.setText("PHP 50.00");
                        break;
                    case "ItemName2":
                        ItemName2.setText("Blueberry Cheesecake");
                        priceLabel2.setText("PHP 50.00");
                        break;
                    case "ItemName3":
                        ItemName3.setText("Strawberry Cheesecake");
                        priceLabel3.setText("PHP 50.00");
                        break;
                    case "ItemName4":
                        ItemName4.setText("Chocolate Cake");
                        priceLabel4.setText("PHP 50.00");
                        break;
                    case "ItemName5":
                        ItemName5.setText("");
                        priceLabel5.setText("");
                        itemQuantity5.setText("");
                        order5.setVisible(false);
                        decrement5.setVisible(false);
                        break;
                    case "ItemName6":
                        ItemName6.setText("");
                        priceLabel6.setText("");
                        itemQuantity6.setText("");
                        order6.setVisible(false);
                        decrement6.setVisible(false);
                        break;
                    case "ItemName7":
                        ItemName7.setText("");
                        priceLabel7.setText("");
                        itemQuantity7.setText("");
                        order7.setVisible(false);
                        decrement7.setVisible(false);
                        break;
                    case "ItemName8":
                        ItemName8.setText("");
                        priceLabel8.setText("");
                        itemQuantity8.setText("");
                        order8.setVisible(false);
                        decrement8.setVisible(false);
                        break;
                    case "ItemName9":
                        ItemName9.setText("");
                        priceLabel9.setText("");
                        itemQuantity9.setText("");
                        order9.setVisible(false);
                        decrement9.setVisible(false);
                        break;
                    case "ItemName10":
                        ItemName10.setText("");
                        priceLabel10.setText("");
                        itemQuantity10.setText("");
                        order10.setVisible(false);
                        decrement10.setVisible(false);
                        break;
               }//Switch end
           }//Else if end
        }//For loop end
    }//Method end
    
    //Method for adding values to categories
    //This is where the functionalities of each button are also specified
    @FXML
    public void addItem(ActionEvent event) throws Exception{
        //Setting the price for each individual item in the food menu
        this.FoodMenu[0][0] = 80;
        this.FoodMenu[0][1] = 60;
        this.FoodMenu[0][2] = 90;
        this.FoodMenu[0][3] = 100;
        this.FoodMenu[0][4] = 60;
        this.FoodMenu[0][5] = 60;
        this.FoodMenu[0][6] = 45;
        this.FoodMenu[0][7] = 60;
        this.FoodMenu[0][8] = 60;
        this.FoodMenu[0][9] = 50;
        
        //Setting the price for each individual item in the drink menu
        this.DrinkMenu[0][0] = 15;
        this.DrinkMenu[0][1] = 15;
        this.DrinkMenu[0][2] = 15;
        this.DrinkMenu[0][3] = 15;
        this.DrinkMenu[0][4] = 45;
        this.DrinkMenu[0][5] = 45;
        this.DrinkMenu[0][6] = 45;
        this.DrinkMenu[0][7] = 45;
        
        //Setting the price for each individual item in the dessert menu
        this.DessertMenu[0][0] = 50;
        this.DessertMenu[0][1] = 50;
        this.DessertMenu[0][2] = 50;
        this.DessertMenu[0][3] = 50;
        
        //If a button is pressed, use the addToFood method with the parameter as the number of the button
        //that triggered the event
        if((Button)event.getSource() == order1){
            confirmCurrentScene(currentScene, 0);
        }
        else if((Button)event.getSource() == order2){
            confirmCurrentScene(currentScene, 1);
        }
        else if((Button)event.getSource() == order3){
            confirmCurrentScene(currentScene, 2);
        }
        else if((Button)event.getSource() == order4){
            confirmCurrentScene(currentScene, 3);
        }
        else if((Button)event.getSource() == order5){
            confirmCurrentScene(currentScene, 4);
        }
        else if((Button)event.getSource() == order6){
            confirmCurrentScene(currentScene, 5);
        }
        else if((Button)event.getSource() == order7){
            confirmCurrentScene(currentScene, 6);
        }
        else if((Button)event.getSource() == order8){
            confirmCurrentScene(currentScene, 7);
        }
        else if((Button)event.getSource() == order9){
            confirmCurrentScene(currentScene, 8);
        }
        else if((Button)event.getSource() == order10){
            confirmCurrentScene(currentScene, 9);
        } 
    }
    
    //Use this method when adding values to the FoodMenu array
    @FXML
    private void addToFood(int number){
        FoodMenu[1][number]++;
        totalNumber++;
        
        //Change the label of the corresponding item selected
        switch(number){
            case 0:
                itemQuantity1.setText("" + FoodMenu[1][number]);
                break;
            case 1:
                itemQuantity2.setText("" + FoodMenu[1][number]);
                break;
            case 2:
                itemQuantity3.setText("" + FoodMenu[1][number]);
                break;
            case 3:
                itemQuantity4.setText("" + FoodMenu[1][number]);
                break;
            case 4:
                itemQuantity5.setText("" + FoodMenu[1][number]);
                break;
            case 5:
                itemQuantity6.setText("" + FoodMenu[1][number]);
                break;
            case 6:
                itemQuantity7.setText("" + FoodMenu[1][number]);
                break;
            case 7:
                itemQuantity8.setText("" + FoodMenu[1][number]);
                break;
            case 8:
                itemQuantity9.setText("" + FoodMenu[1][number]);
                break;
            case 9:
                itemQuantity10.setText("" + FoodMenu[1][number]);
                break;
        }
        numberOfItems.setText("" + totalNumber);
        
        totalPrice += FoodMenu[0][number];
        grandTotal.setText("PHP\t" + totalPrice + ".00");
    }
    
    //Use this method when adding values to the DrinkMenu array
    @FXML
    private void addToDrinks(int number){
        DrinkMenu[1][number]++;
        totalNumber++;
        
        //Change the label of the corresponding item selected
        switch(number){
            case 0:
                itemQuantity1.setText("" + DrinkMenu[1][number]);
                break;
            case 1:
                itemQuantity2.setText("" + DrinkMenu[1][number]);
                break;
            case 2:
                itemQuantity3.setText("" + DrinkMenu[1][number]);
                break;
            case 3:
                itemQuantity4.setText("" + DrinkMenu[1][number]);
                break;
            case 4:
                itemQuantity5.setText("" + DrinkMenu[1][number]);
                break;
            case 5:
                itemQuantity6.setText("" + DrinkMenu[1][number]);
                break;
            case 6:
                itemQuantity7.setText("" + DrinkMenu[1][number]);
                break;
            case 7:
                itemQuantity8.setText("" + DrinkMenu[1][number]);
                break;
        }
        numberOfItems.setText("" + totalNumber);
        
        totalPrice += DrinkMenu[0][number];
        grandTotal.setText("PHP\t" + totalPrice + ".00");
    }
    
    //Use this method when adding values to the DessertMenu array
    @FXML
    private void addToDesserts(int number){
        DessertMenu[1][number]++;
        totalNumber++;
        
        //Change the label of the corresponding item selected
        switch(number){
            case 0:
                itemQuantity1.setText("" + DessertMenu[1][number]);
                break;
            case 1:
                itemQuantity2.setText("" + DessertMenu[1][number]);
                break;
            case 2:
                itemQuantity3.setText("" + DessertMenu[1][number]);
                break;
            case 3:
                itemQuantity4.setText("" + DessertMenu[1][number]);
                break;
        }
        numberOfItems.setText("" + totalNumber);
        
        totalPrice += DessertMenu[0][number];
        grandTotal.setText("PHP\t" + totalPrice + ".00");
    }
    
    @FXML
    public void confirmCurrentScene(String sceneName, int number){
        //First check if the user is on the food, drink or dessert screen
        switch(sceneName){
            case "Food":
                //Depending on the button pressed, do a different computation on the specified array cell
                switch(number){
                    case 0:
                        addToFood(0);
                        break;
                    case 1:
                        addToFood(1);
                        break;
                    case 2:
                        addToFood(2);
                        break;
                    case 3:
                        addToFood(3);
                        break;
                    case 4:
                        addToFood(4);
                        break;
                    case 5:
                        addToFood(5);
                        break;
                    case 6:
                        addToFood(6);
                        break;
                    case 7:
                        addToFood(7);
                        break;
                    case 8:
                        addToFood(8);
                        break;
                    case 9:
                        addToFood(9);
                        break;
                }//End of switch
                break;
                
            case "Drinks":
                //Depending on the button pressed, do a different computation on the specified array cell
                switch(number){
                    case 0:
                        addToDrinks(0);
                        break;
                    case 1:
                        addToDrinks(1);
                        break;
                    case 2:
                        addToDrinks(2);
                        break;
                    case 3:
                        addToDrinks(3);
                        break;
                    case 4:
                        addToDrinks(4);
                        break;
                    case 5:
                        addToDrinks(5);
                        break;
                    case 6:
                        addToDrinks(6);
                        break;
                    case 7:
                        addToDrinks(7);
                        break;
                }//End of switch
                break;
            case "Desserts":
                switch(number){
                    case 0:
                        addToDesserts(0);
                        break;
                    case 1:
                        addToDesserts(1);
                        break;
                    case 2:
                        addToDesserts(2);
                        break;
                    case 3:
                        addToDesserts(3);
                        break;
                }//End of switch
                break;
        }//End of switch
    }
    
    @FXML
    public void DecreaseItemCount(ActionEvent event) throws Exception{     
        if((Button)event.getSource() == decrement1){
            subtract(currentScene, 0);
        }
        else if((Button)event.getSource() == decrement2){
            subtract(currentScene, 1);
        }
        else if((Button)event.getSource() == decrement3){
            subtract(currentScene, 2);
        }
        else if((Button)event.getSource() == decrement4){
            subtract(currentScene, 3);
        }
        else if((Button)event.getSource() == decrement5){
            subtract(currentScene, 4);
        }
        else if((Button)event.getSource() == decrement6){
            subtract(currentScene, 5);
        }
        else if((Button)event.getSource() == decrement7){
            subtract(currentScene, 6);
        }
        else if((Button)event.getSource() == decrement8){
            subtract(currentScene, 7);
        }
        else if((Button)event.getSource() == decrement9){
            subtract(currentScene, 8);
        }
        else if((Button)event.getSource() == decrement10){
            subtract(currentScene, 9);
        } 
    }
    
    //Use this method when subtracting values to the FoodMenu array
    @FXML
    private void subtractFood(int number){
        if(FoodMenu[1][number] > 0){
            FoodMenu[1][number]--;
            totalNumber--;
            
            //Change the label of the corresponding item selected
            switch(number){
                case 0:
                    itemQuantity1.setText("" + FoodMenu[1][number]);
                    break;
                case 1:
                    itemQuantity2.setText("" + FoodMenu[1][number]);
                    break;
                case 2:
                    itemQuantity3.setText("" + FoodMenu[1][number]);
                    break;
                case 3:
                    itemQuantity4.setText("" + FoodMenu[1][number]);
                    break;
                case 4:
                    itemQuantity5.setText("" + FoodMenu[1][number]);
                    break;
                case 5:
                    itemQuantity6.setText("" + FoodMenu[1][number]);
                    break;
                case 6:
                    itemQuantity7.setText("" + FoodMenu[1][number]);
                    break;
                case 7:
                    itemQuantity8.setText("" + FoodMenu[1][number]);
                    break;
                case 8:
                    itemQuantity9.setText("" + FoodMenu[1][number]);
                    break;
                case 9:
                    itemQuantity10.setText("" + FoodMenu[1][number]);
                    break;
            }//Switch End
            numberOfItems.setText("" + totalNumber);

            totalPrice -= FoodMenu[0][number];
            grandTotal.setText("PHP\t" + totalPrice + ".00");
        }//If End
    }
    
    //Use this method when subtracting values from the DrinkMenu array
    @FXML
    private void subtractDrinks(int number){
        if(DrinkMenu[1][number] > 0){
            
            DrinkMenu[1][number]--;
            totalNumber--;
            
            //Change the label of the corresponding item selected
            switch(number){
                case 0:
                    itemQuantity1.setText("" + DrinkMenu[1][number]);
                    break;
                case 1:
                    itemQuantity2.setText("" + DrinkMenu[1][number]);
                    break;
                case 2:
                    itemQuantity3.setText("" + DrinkMenu[1][number]);
                    break;
                case 3:
                    itemQuantity4.setText("" + DrinkMenu[1][number]);
                    break;
                case 4:
                    itemQuantity5.setText("" + DrinkMenu[1][number]);
                    break;
                case 5:
                    itemQuantity6.setText("" + DrinkMenu[1][number]);
                    break;
                case 6:
                    itemQuantity7.setText("" + DrinkMenu[1][number]);
                    break;
                case 7:
                    itemQuantity8.setText("" + DrinkMenu[1][number]);
                    break;
            }//Switch End
            numberOfItems.setText("" + totalNumber);

            totalPrice -= DrinkMenu[0][number];
            grandTotal.setText("PHP\t" + totalPrice + ".00");
        }//If End
    }
    
    //Use this method when subtracting values from the DessertMenu array
    @FXML
    private void subtractDesserts(int number){
        if(DessertMenu[1][number] > 0){
            
            DessertMenu[1][number]--;
            totalNumber--;
            
            //Change the label of the corresponding item selected
            switch(number){
                case 0:
                    itemQuantity1.setText("" + DessertMenu[1][number]);
                    break;
                case 1:
                    itemQuantity2.setText("" + DessertMenu[1][number]);
                    break;
                case 2:
                    itemQuantity3.setText("" + DessertMenu[1][number]);
                    break;
                case 3:
                    itemQuantity4.setText("" + DessertMenu[1][number]);
                    break;
            }//Switch End
        
            numberOfItems.setText("" + totalNumber);
        
            totalPrice -= DessertMenu[0][number];
            grandTotal.setText("PHP\t" + totalPrice + ".00");
        }//If End    
    }
    
    @FXML
    public void subtract(String currentScene, int buttonNumber){
        //First check if the user is on the food, drink or dessert screen
        switch(currentScene){
            case "Food":
                //Depending on the button pressed, do a different computation on the specified array cell
                switch(buttonNumber){
                    case 0:
                        subtractFood(0);
                        break;
                    case 1:
                        subtractFood(1);
                        break;
                    case 2:
                        subtractFood(2);
                        break;
                    case 3:
                        subtractFood(3);
                        break;
                    case 4:
                        subtractFood(4);
                        break;
                    case 5:
                        subtractFood(5);
                        break;
                    case 6:
                        subtractFood(6);
                        break;
                    case 7:
                        subtractFood(7);
                        break;
                    case 8:
                        subtractFood(8);
                        break;
                    case 9:
                        subtractFood(9);
                        break;
                }//End of switch
                break;
                
            case "Drinks":
                //Depending on the button pressed, do a different computation on the specified array cell
                switch(buttonNumber){
                    case 0:
                        subtractDrinks(0);
                        break;
                    case 1:
                        subtractDrinks(1);
                        break;
                    case 2:
                        subtractDrinks(2);
                        break;
                    case 3:
                        subtractDrinks(3);
                        break;
                    case 4:
                        subtractDrinks(4);
                        break;
                    case 5:
                        subtractDrinks(5);
                        break;
                    case 6:
                        subtractDrinks(6);
                        break;
                    case 7:
                        subtractDrinks(7);
                        break;
                }//End of switch
                break;
            case "Desserts":
                switch(buttonNumber){
                    case 0:
                        subtractDesserts(0);
                        break;
                    case 1:
                        subtractDesserts(1);
                        break;
                    case 2:
                        subtractDesserts(2);
                        break;
                    case 3:
                        subtractDesserts(3);
                        break;
                }//End of switch
                break;
        }//End of switch
    }
    
    @FXML
    public void FinishOrdering(){
        AppToDatabase send = new AppToDatabase();
        send.StoreOrder(userName, FoodMenu, DrinkMenu, DessertMenu, totalPrice);
        
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setContentText("Successfully placed an order!");
        alert.showAndWait();
    }
    
    @FXML
    public void signOut(ActionEvent event) throws Exception{
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("FXMLDocument.fxml"));
        Parent login = loader.load();
        
        Scene loginScene = new Scene(login);
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.close();
        
        Stage next = new Stage();
        next.setScene(loginScene);
        next.setTitle("Login");
        next.show();
        next.setMaxWidth(810);
        next.setMaxHeight(630);
        next.centerOnScreen();
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
